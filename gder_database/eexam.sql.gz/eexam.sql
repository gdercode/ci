-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 14, 2021 at 08:28 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.1.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eexam`
--

-- --------------------------------------------------------

--
-- Table structure for table `all_user_table`
--

CREATE TABLE `all_user_table` (
  `user_id` int(11) NOT NULL,
  `user_first_name` varchar(50) NOT NULL,
  `user_last_name` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_mobile` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `user_password` varchar(200) NOT NULL,
  `registration_date` datetime NOT NULL,
  `user_update_date` datetime NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `all_user_table`
--

INSERT INTO `all_user_table` (`user_id`, `user_first_name`, `user_last_name`, `user_email`, `user_mobile`, `username`, `user_password`, `registration_date`, `user_update_date`, `role_id`) VALUES
(3, 'superAdmin', 'superAdmin', 'superAdmin@gmail.com', '+250783628765', 'superAdmin', '$2y$10$pikNATYKG6CEpOj5R38Dx.AdQUarxdW3LNEj1Fh0ldeqH2mLbSuum', '2021-06-14 11:41:48', '0000-00-00 00:00:00', 1),
(9, 'student', 'student', 'maker@gmail.com', '+25055265898', 'student', '$2y$10$TAIbbKO6NNuByVNLld0JW.3opebKMzWXpHMOMyIJzBKlgHi0jdiXG', '2021-06-16 14:15:46', '2021-07-04 09:02:57', 5),
(14, 'anyUser', 'anyUser', 'gusengaderrick@gmail.com', '+250783628865', 'anyUser', '$2y$10$VH.vd6mGZr/kB6ROfYV7QOcks5GUR/LZKdmasB/fEXgaPfB7tTXse', '2021-06-16 18:21:06', '2021-07-04 09:02:27', 2),
(16, 'teacher', 'teacher', 'gusengaderrick34@gmail.com', '+2505526545', 'teacher', '$2y$10$InhQvuojCyKdNv2hI9pAFOljjWsQhT0oUnCqIUmCi9U97oL8ZBRNu', '2021-06-20 10:17:30', '0000-00-00 00:00:00', 7),
(17, 'student2', 'student2', 'student2@gmail.com', '+250793628765', 'student2', '$2y$10$ZfuM1KHeBnH6Z5lDEwcgeu8R82HvDa0kDEKvNLvssrVNx1j3Xd4zu', '2021-07-11 08:41:52', '0000-00-00 00:00:00', 5);

-- --------------------------------------------------------

--
-- Table structure for table `answer_table`
--

CREATE TABLE `answer_table` (
  `answer_id` int(11) NOT NULL,
  `answer_title` text NOT NULL,
  `answer_status` varchar(50) NOT NULL,
  `id_question` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `answer_table`
--

INSERT INTO `answer_table` (`answer_id`, `answer_title`, `answer_status`, `id_question`) VALUES
(20, 'answer ya gatatu', 'right', 101),
(21, 'answer ya kabiri \r\n', 'wrong', 101),
(37, 'answer yambere\r\n', 'wrong', 101),
(39, '1', 'wrong', 103),
(44, 'oya', 'wrong', 104),
(46, 'ego', 'right', 104),
(50, '6', 'right', 103),
(51, 'fgdg', 'wrong', 103),
(52, 'ghj', 'right', 103),
(54, 'answer 1', 'wrong', 123),
(55, 'answer 2', 'wrong', 123),
(56, 'answer 3', 'right', 123),
(57, 'answer 5', 'wrong', 123),
(58, 'answer 6', 'right', 123),
(59, 'ego', 'right', 121),
(60, 'oya', 'wrong', 121),
(61, 'one', 'wrong', 120),
(62, 'two', 'wrong', 120),
(63, 'three', 'right', 120),
(64, 'four', 'right', 120),
(65, 'rimwe', 'wrong', 119),
(66, 'kabiri', 'right', 119),
(67, 'gatatu', 'wrong', 119),
(68, 'gatatu', 'wrong', 119),
(69, 'gatatu', 'wrong', 119),
(70, 'gatatu', 'wrong', 119),
(71, 'gatatu', 'wrong', 119),
(72, 'gatatu', 'wrong', 119),
(73, 'gatatu', 'wrong', 119),
(74, 'yego', 'right', 126),
(75, 'hoya', 'right', 126),
(76, 'jj', 'wrong', 126);

-- --------------------------------------------------------

--
-- Table structure for table `course_table`
--

CREATE TABLE `course_table` (
  `module_id` varchar(50) NOT NULL,
  `module_name` varchar(50) NOT NULL,
  `module_credit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_table`
--

INSERT INTO `course_table` (`module_id`, `module_name`, `module_credit`) VALUES
('101010', 'DCF', 20),
('101110', 'Calculus', 20),
('kiny1234', 'Kinyarwanda', 10);

-- --------------------------------------------------------

--
-- Table structure for table `exam_monitoring_table`
--

CREATE TABLE `exam_monitoring_table` (
  `id_of_user` int(11) NOT NULL,
  `id_of_exam` int(11) NOT NULL,
  `eye_focus_lost` int(11) NOT NULL,
  `page_focus_lost` int(11) NOT NULL,
  `number_of_attemption` int(11) NOT NULL,
  `submition_status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_monitoring_table`
--

INSERT INTO `exam_monitoring_table` (`id_of_user`, `id_of_exam`, `eye_focus_lost`, `page_focus_lost`, `number_of_attemption`, `submition_status`) VALUES
(17, 12, 49, 38, 27, 'submit'),
(9, 12, 197, 40, 10, 'none');

-- --------------------------------------------------------

--
-- Table structure for table `exam_table`
--

CREATE TABLE `exam_table` (
  `exam_id` int(11) NOT NULL,
  `exam_title` varchar(50) NOT NULL,
  `exam_description` text NOT NULL,
  `exam_open_date` date NOT NULL,
  `exam_open_time` time NOT NULL,
  `exam_close_date` date NOT NULL,
  `exam_close_time` time NOT NULL,
  `exam_grade` int(11) NOT NULL,
  `exam_pass_grade` int(11) NOT NULL,
  `course_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_table`
--

INSERT INTO `exam_table` (`exam_id`, `exam_title`, `exam_description`, `exam_open_date`, `exam_open_time`, `exam_close_date`, `exam_close_time`, `exam_grade`, `exam_pass_grade`, `course_id`) VALUES
(7, 'Exam yambere', 'gfsgv', '2021-08-04', '18:30:00', '2021-08-04', '18:31:00', 50, 80, '101010'),
(8, 'Exam yambere', 'fsddddddddvgsfgdfvsgdfgvvvvvvvvvvv', '2021-07-05', '22:03:00', '2021-07-06', '22:04:00', 45, 60, 'kiny1234'),
(10, 'Exam yambere ya gatatu', 'gusenga Nivyo vyogukiza gusa', '2021-08-04', '23:33:00', '2021-08-06', '23:33:00', 45, 60, 'kiny1234'),
(12, 'EXAM TEST', 'exam', '2021-07-21', '07:00:00', '2021-09-30', '22:00:00', 45, 60, 'kiny1234');

-- --------------------------------------------------------

--
-- Table structure for table `question_exam_connection_table`
--

CREATE TABLE `question_exam_connection_table` (
  `question_exam_connection_id` int(11) NOT NULL,
  `question_ids` int(11) NOT NULL,
  `exam_ids` int(11) NOT NULL,
  `question_grade` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question_exam_connection_table`
--

INSERT INTO `question_exam_connection_table` (`question_exam_connection_id`, `question_ids`, `exam_ids`, `question_grade`) VALUES
(53, 104, 12, 5),
(63, 127, 12, 2),
(64, 128, 12, 6);

-- --------------------------------------------------------

--
-- Table structure for table `question_table`
--

CREATE TABLE `question_table` (
  `question_id` int(11) NOT NULL,
  `question_title` text NOT NULL,
  `question_category` varchar(50) NOT NULL,
  `course_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question_table`
--

INSERT INTO `question_table` (`question_id`, `question_title`, `question_category`, `course_id`) VALUES
(101, 'ikibazo cyambere\r\n', 'multiple_response', 'kiny1234'),
(103, 'question ya test ya mbere', 'multiple_choice', 'kiny1234'),
(104, 'Ishura ego canke oya ', 'true_or_false', 'kiny1234'),
(119, 'multiple_choice', 'multiple_choice', '101110'),
(120, 'multiple_response', 'multiple_response', '101110'),
(121, 'true_or_false', 'true_or_false', '101110'),
(122, 'short_answer', 'short_answer', '101110'),
(123, 'select_from_lists', 'select_from_lists', '101110'),
(124, 'essay', 'essay', '101110'),
(126, 'gder other Question', 'multiple_choice', 'kiny1234'),
(127, 'essay question', 'essay', 'kiny1234'),
(128, 'empty answer multiple responses', 'multiple_response', 'kiny1234');

-- --------------------------------------------------------

--
-- Table structure for table `role_table`
--

CREATE TABLE `role_table` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(50) NOT NULL,
  `role_percentage` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role_table`
--

INSERT INTO `role_table` (`role_id`, `role_name`, `role_percentage`) VALUES
(1, 'superAdmin', 100),
(2, 'anyUser', 10),
(5, 'Student', 50),
(7, 'teacher', 75);

-- --------------------------------------------------------

--
-- Table structure for table `student_answers_table`
--

CREATE TABLE `student_answers_table` (
  `userID` int(11) NOT NULL,
  `examID` int(11) NOT NULL,
  `questionID` int(11) NOT NULL,
  `answer` text NOT NULL,
  `answer_grade` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_answers_table`
--

INSERT INTO `student_answers_table` (`userID`, `examID`, `questionID`, `answer`, `answer_grade`) VALUES
(3, 12, 104, 'ego', 5),
(3, 12, 127, 'ffgf', 2),
(9, 12, 104, 'oya', 0),
(9, 12, 127, 'the right answerklvmbniush', 1001),
(17, 12, 104, 'oya', 0),
(17, 12, 127, 'Niko biri', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_course_connection_table`
--

CREATE TABLE `user_course_connection_table` (
  `userID` int(11) NOT NULL,
  `moduleID` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_course_connection_table`
--

INSERT INTO `user_course_connection_table` (`userID`, `moduleID`) VALUES
(9, 'kiny1234'),
(16, 'kiny1234'),
(17, 'kiny1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `all_user_table`
--
ALTER TABLE `all_user_table`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `answer_table`
--
ALTER TABLE `answer_table`
  ADD PRIMARY KEY (`answer_id`),
  ADD KEY `question_id` (`id_question`);

--
-- Indexes for table `course_table`
--
ALTER TABLE `course_table`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `exam_monitoring_table`
--
ALTER TABLE `exam_monitoring_table`
  ADD KEY `id_of_exam` (`id_of_exam`),
  ADD KEY `id_of_user` (`id_of_user`);

--
-- Indexes for table `exam_table`
--
ALTER TABLE `exam_table`
  ADD PRIMARY KEY (`exam_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `question_exam_connection_table`
--
ALTER TABLE `question_exam_connection_table`
  ADD PRIMARY KEY (`question_exam_connection_id`),
  ADD KEY `exam_id` (`exam_ids`),
  ADD KEY `question_id` (`question_ids`);

--
-- Indexes for table `question_table`
--
ALTER TABLE `question_table`
  ADD PRIMARY KEY (`question_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `role_table`
--
ALTER TABLE `role_table`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `student_answers_table`
--
ALTER TABLE `student_answers_table`
  ADD KEY `examID` (`examID`),
  ADD KEY `questionID` (`questionID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `user_course_connection_table`
--
ALTER TABLE `user_course_connection_table`
  ADD KEY `module_id` (`moduleID`),
  ADD KEY `user` (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `all_user_table`
--
ALTER TABLE `all_user_table`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `answer_table`
--
ALTER TABLE `answer_table`
  MODIFY `answer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `exam_table`
--
ALTER TABLE `exam_table`
  MODIFY `exam_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `question_exam_connection_table`
--
ALTER TABLE `question_exam_connection_table`
  MODIFY `question_exam_connection_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `question_table`
--
ALTER TABLE `question_table`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT for table `role_table`
--
ALTER TABLE `role_table`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `all_user_table`
--
ALTER TABLE `all_user_table`
  ADD CONSTRAINT `all_user_table_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role_table` (`role_id`);

--
-- Constraints for table `answer_table`
--
ALTER TABLE `answer_table`
  ADD CONSTRAINT `answer_table_ibfk_1` FOREIGN KEY (`id_question`) REFERENCES `question_table` (`question_id`);

--
-- Constraints for table `exam_monitoring_table`
--
ALTER TABLE `exam_monitoring_table`
  ADD CONSTRAINT `exam_monitoring_table_ibfk_1` FOREIGN KEY (`id_of_exam`) REFERENCES `exam_table` (`exam_id`),
  ADD CONSTRAINT `exam_monitoring_table_ibfk_2` FOREIGN KEY (`id_of_user`) REFERENCES `all_user_table` (`user_id`);

--
-- Constraints for table `exam_table`
--
ALTER TABLE `exam_table`
  ADD CONSTRAINT `exam_table_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `course_table` (`module_id`);

--
-- Constraints for table `question_exam_connection_table`
--
ALTER TABLE `question_exam_connection_table`
  ADD CONSTRAINT `question_exam_connection_table_ibfk_1` FOREIGN KEY (`exam_ids`) REFERENCES `exam_table` (`exam_id`),
  ADD CONSTRAINT `question_exam_connection_table_ibfk_2` FOREIGN KEY (`question_ids`) REFERENCES `question_table` (`question_id`);

--
-- Constraints for table `question_table`
--
ALTER TABLE `question_table`
  ADD CONSTRAINT `question_table_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `course_table` (`module_id`);

--
-- Constraints for table `student_answers_table`
--
ALTER TABLE `student_answers_table`
  ADD CONSTRAINT `student_answers_table_ibfk_1` FOREIGN KEY (`examID`) REFERENCES `exam_table` (`exam_id`),
  ADD CONSTRAINT `student_answers_table_ibfk_2` FOREIGN KEY (`questionID`) REFERENCES `question_table` (`question_id`),
  ADD CONSTRAINT `student_answers_table_ibfk_3` FOREIGN KEY (`userID`) REFERENCES `all_user_table` (`user_id`);

--
-- Constraints for table `user_course_connection_table`
--
ALTER TABLE `user_course_connection_table`
  ADD CONSTRAINT `user_course_connection_table_ibfk_1` FOREIGN KEY (`moduleID`) REFERENCES `course_table` (`module_id`),
  ADD CONSTRAINT `user_course_connection_table_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `all_user_table` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
